package com.example.demo.services;

//import com.example.demo.dao.AdminStorage;
import com.example.demo.dao.UserStorage;
//import com.example.demo.models.Admin;
import com.example.demo.models.Product;
import com.example.demo.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class UserService {
    @Autowired
    private UserStorage userStorage;
    public boolean createAccount(User user)
    {
        return userStorage.createAccount(user);
    }

    public boolean login(String email,String password){
        return userStorage.login(email,password);
    }

    public ResponseEntity<List<Product>> showProduct()
    {
        return userStorage.showProduct();
    }
    public ResponseEntity<String> changePassword(String email, String password)
    {
        return userStorage.changePassword(email,password);
    }

    public ResponseEntity<String> forgotPassword(String email)
    {
        return userStorage.forgotPassword(email);
    }
    public boolean productAddition(Map<String,Integer> productList)
    {
        return userStorage.productAddition(productList);
    }

    public ResponseEntity<Map<String,Integer>> getAllProducts()
    {
        return userStorage.getAllProducts();
    }
    public boolean deleteProduct(Map<String,Integer> map)
    {
        return  userStorage.productDelete(map);
    }
    public boolean updateProduct(Map<String,Integer> integerMap)
    {
        return userStorage.productUpdate(integerMap);
    }

}
