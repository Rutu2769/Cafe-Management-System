package com.example.demo.dao;

import com.example.demo.models.Product;
import com.example.demo.models.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class UserStorage {
    private boolean isUser;
    private HashMap<String, Integer> productName = new HashMap<>();

    private static EntityManagerFactory getEntity() {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("default");
        return entityManagerFactory;
    }

    public boolean createAccount(User user) {
        EntityManagerFactory entityManagerFactory = getEntity();
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        String email = user.getEmail();
        Query query = entityManager.createQuery("from User where email = :email");
        query.setParameter("email", email);
        List<User> userList = query.getResultList();

        if (userList.isEmpty()) {
            entityManager.persist(user);
            isUser = true;
            entityManager.getTransaction().commit();
            entityManager.close();
            entityManagerFactory.close();
            return true;
        } else {
            entityManager.getTransaction().commit();
            entityManager.close();
            entityManagerFactory.close();
            return false;
        }

    }

    public boolean login(String email, String password) {
        EntityManagerFactory entityManagerFactory = getEntity();
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        Query query = entityManager.createQuery("from User where email = :email");
        query.setParameter("email", email);
        List<User> userList = query.getResultList();

        if (userList.isEmpty()) {
            entityManager.getTransaction().commit();
            entityManager.close();
            entityManagerFactory.close();

        } else {
            if (userList.get(0).getPassword().equals(password)) {
                isUser = true;
                entityManager.getTransaction().commit();
                entityManager.close();
                entityManagerFactory.close();
                return true;
            }
        }
        return false;
    }

    public ResponseEntity<List<Product>> showProduct() {
        EntityManagerFactory entityManagerFactory = getEntity();
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            Query query = entityManager.createQuery("from Product");
//            if (isUser)
                return new ResponseEntity<>(query.getResultList(), HttpStatus.OK);

        } catch (Exception exception) {
            exception.printStackTrace();
        } finally {
            entityManager.getTransaction().commit();
            entityManager.close();
            entityManagerFactory.close();
        }
        return new ResponseEntity<>(new ArrayList<>(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public ResponseEntity<String> forgotPassword(String email) {
        EntityManagerFactory entityManagerFactory = getEntity();
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            Query query = entityManager.createQuery("from User where email = :email");
            query.setParameter("email", email);
            List<User> stringList = query.getResultList();

            if (!stringList.isEmpty()) {
                String password = stringList.get(0).getPassword();
                return new ResponseEntity(password, HttpStatus.OK);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            entityManager.getTransaction().commit();
            entityManager.close();
            entityManagerFactory.close();
        }
        return new ResponseEntity("email not consist", HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public ResponseEntity<String> changePassword(String email, String password) {
        EntityManagerFactory entityManagerFactory = getEntity();
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            Query query = entityManager.createQuery("from User where email =: email");
            query.setParameter("email", email);
            List<User> userList = query.getResultList();

            if (!userList.isEmpty()) {
                Query query1 = entityManager.createQuery("update User set password =: password where email =: email");
                query1.setParameter("email", email);
                query1.setParameter("password", password);
                query1.executeUpdate();
                return new ResponseEntity<>("Password has been updated successfully", HttpStatus.OK);
            }
            return new ResponseEntity("Email id is wrong", HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception exception) {
            exception.printStackTrace();
        } finally {
            entityManager.getTransaction().commit();
            entityManager.close();
            entityManagerFactory.close();
        }
        return new ResponseEntity("SOMETHING_WENT_WRONG", HttpStatus.INTERNAL_SERVER_ERROR);
    }


    public boolean productAddition(Map<String, Integer> productList) {
//        try {
//            if (!productList.isEmpty()) {
//                productName.putAll(productList);
//                return true;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return false;

        try {
            EntityManagerFactory entityManagerFactory = getEntity();
            EntityManager entityManager = entityManagerFactory.createEntityManager();
            for (Map.Entry<String, Integer> entry : productList.entrySet()) {
                String name = entry.getKey();
                Query query = entityManager.createQuery("from Product where name =: name");
                query.setParameter("name", name);
                List<String> stringList = query.getResultList();
                if (stringList.isEmpty()) {
                    return false;
                }
            }
            productName.putAll(productList);
            return true;
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        return false;
    }

    public ResponseEntity<Map<String, Integer>> getAllProducts(){
        try {
//            List<String > stringList = new ArrayList<>();
//            for(Map.Entry<String,Integer> entry:productName.entrySet())
//            {
//                stringList.add(entry.getKey());
//            }
            return new ResponseEntity<>(productName,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
        }

        return new ResponseEntity<>(new HashMap<>(), HttpStatus.INTERNAL_SERVER_ERROR);
    }


    public boolean productDelete(Map<String, Integer> list) {
        if (!list.isEmpty() && !productName.isEmpty()) {
            for (Map.Entry<String, Integer> entry : list.entrySet())
            {
                int flag = 0;
                for(Map.Entry<String,Integer> entry1:productName.entrySet())
                {
                    String name = entry.getKey();
                    if(name.equals(entry1.getKey())) {
                        flag=1;
                        productName.remove(name);
                    }
                }
                if(flag==0)
                    return false;
            }
            return true;
        }
        return false;
    }

    public boolean productUpdate(Map<String,Integer> map)
    {
        if(!map.isEmpty() && !productName.isEmpty())
        {
            for(Map.Entry<String,Integer> entry:map.entrySet())
            {
                int flag = 0;
                for(Map.Entry<String,Integer> entry1: productName.entrySet()) {
                    if (entry.getKey().equals(entry1.getKey()))
                    {
                        flag = 1;
                        entry1.setValue(entry.getValue());
                    }
                }
               if(flag==0)
                   return false;
            }
            return  true;
        }
       return false;
    }
}
