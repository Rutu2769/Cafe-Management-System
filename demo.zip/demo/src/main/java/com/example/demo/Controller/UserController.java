package com.example.demo.Controller;

import com.example.demo.models.Product;
import com.example.demo.models.User;
import com.example.demo.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping(value = "/createAccount", consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> createAccount(@RequestBody User user)
    {
        ResponseEntity<String> responseEntity;
        if(userService.createAccount(user))
            responseEntity = new ResponseEntity<>("Account created successfully", HttpStatus.CREATED);
        else
            responseEntity = new ResponseEntity<>("Account creation failed", HttpStatus.INTERNAL_SERVER_ERROR);
        return responseEntity;
    }

    @PostMapping(value = "/login/{email}/{password}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> login(@PathVariable(name = "email") String email,
                                        @PathVariable(name = "password") String password) {
        ResponseEntity<String> responseEntity;
            if(userService.login(email,password)) {
                responseEntity = new ResponseEntity<>("login success", HttpStatus.ACCEPTED);
                return responseEntity;
        }
        responseEntity = new ResponseEntity<>("Wait for admin approval.", HttpStatus.INTERNAL_SERVER_ERROR);
        return responseEntity;
    }

    @GetMapping(value = "/showProduct",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Product>> showProduct()
    {
        try {
            return userService.showProduct();
        } catch (Exception exception){
            exception.printStackTrace();
        }
        return new ResponseEntity<>(new ArrayList<>(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PostMapping(value = "/forgotPassword/{email}",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> forgotPassword(@PathVariable(name = "email")String email)
    {
        try {
            return userService.forgotPassword(email);
        } catch (Exception exception){
            exception.printStackTrace();
        }
        return new ResponseEntity<>("Invalid email",HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PostMapping(value = "/changePassword/{email}/{password}",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> changePassword(@PathVariable (name = "email") String email,
                                                 @PathVariable (name = "password") String password)
    {
        try {
            return userService.changePassword(email, password);
        } catch (Exception exception){
            exception.printStackTrace();
        }
        return new ResponseEntity<>("Invalid email",HttpStatus.INTERNAL_SERVER_ERROR);
    }


    @PostMapping(value = "/productAddition", consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> productAddition(@RequestBody Map<String,Integer> productList)
    {
        ResponseEntity<String> responseEntity;
        if(userService.productAddition(productList))
            responseEntity = new ResponseEntity<>("Product Added successfully", HttpStatus.CREATED);
        else
            responseEntity = new ResponseEntity<>("Product is not valid", HttpStatus.INTERNAL_SERVER_ERROR);
        return responseEntity;

    }

    @GetMapping(value = "/getAllProducts",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, Integer>> getAllProducts()
    {
        try {
            return userService.getAllProducts();
        } catch (Exception exception){
            exception.printStackTrace();
        }
        return new ResponseEntity<>(new HashMap<>(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PostMapping(value = "/productDelete",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> productDelete(@RequestBody Map<String,Integer> map)
    {
        ResponseEntity<String> responseEntity;
        if(userService.deleteProduct(map))
            responseEntity = new ResponseEntity<>("Product deleted successfully",HttpStatus.OK);
        else
            responseEntity = new ResponseEntity<>("Product deletion failed",HttpStatus.BAD_REQUEST);
        return responseEntity;
    }

    @PutMapping(value = "/productUpdate",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> productUpdate(@RequestBody Map<String, Integer> map)
    {
        ResponseEntity<String> responseEntity;
        if (userService.updateProduct(map))
            responseEntity = new ResponseEntity<>("Product updated successfully",HttpStatus.OK);
        else
            responseEntity = new ResponseEntity<>("Product updation failed",HttpStatus.INTERNAL_SERVER_ERROR);
        return responseEntity;

    }


}
